<?php

require __DIR__ . '/../vendor/autoload.php';

define('ROOT_TEST_DIR', __DIR__ . '/OpenCloud/Tests/');