<?php

namespace OpenCloud\Common\Exceptions;

class InstanceDeleteError extends \Exception {}
