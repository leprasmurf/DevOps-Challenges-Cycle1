<?php

namespace OpenCloud\Common\Exceptions;

class UrlError extends \Exception {}
