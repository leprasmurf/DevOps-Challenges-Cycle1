<?php

namespace OpenCloud\Common\Exceptions;

class InvalidRequestError extends \Exception {}
